#!/bin/bash
sudo mysql --local-infile=1 CS430
