select '***clean***' AS '';
source scripts/clean.sql;
select '***buildDB***' AS '';
source scripts/buildDB.sql;
select '***importData***' AS '';
source scripts/importData.sql;