#!/bin/bash
python3 author-conform.py
python3 books-conform.py
python3 members-conform.py
python3 publisher-conform.py
python3 spbooks-conform.py